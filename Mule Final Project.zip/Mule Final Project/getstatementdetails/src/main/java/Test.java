import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.VerticalPositionMark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test implements Callable{

	 private static final String FILE_NAME = "d:/statement.pdf";
	 private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);
	 private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 4, Font.BOLD);
	 
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message = eventContext.getMessage();
		//System.out.println("java class: "+ message.getPayloadAsString());
		String response = message.getPayloadAsString();
		
		JSONArray jArray = new JSONArray(response);
		JSONObject jsonobjectHeader = jArray.getJSONObject(0);
		String bankName = jsonobjectHeader.getString("name");
		String customerPreFix = jsonobjectHeader.getString("Prefix");
		String customerFirstName = jsonobjectHeader.getString("First");
		String customerLastName = jsonobjectHeader.getString("Last");
		String customerAddressLine1 = jsonobjectHeader.getString("Line1");
		String customerAddressLine2 = jsonobjectHeader.getString("Line2");
		String customerCity = jsonobjectHeader.getString("City");
		String customerState = jsonobjectHeader.getString("State");
		String customerZip = jsonobjectHeader.getString("Zip");
		String customerCountry = jsonobjectHeader.getString("Country");
		String customerId = jsonobjectHeader.getString("customerId");
		String currency = jsonobjectHeader.getString("Currency");
		String accountNumber = jsonobjectHeader.getString("AccountNumber");
		//System.out.println("----------------------Statement Header-------------------------");
		
		// writing content into PDF file
		Document document = new Document();
		PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
		document.open();
		 Paragraph preface1 = new Paragraph();
		 preface1.add("Bank ");
		 preface1.add(bankName);
		 preface1.setAlignment(Element.ALIGN_CENTER);
		 preface1.setFont(FontFactory.getFont(FontFactory.TIMES, 20f));
         document.add(preface1);
         
         Chunk glue = new Chunk(new VerticalPositionMark());
         Paragraph preface2 = new Paragraph();
         addEmptyLine(preface2, 3);
         preface2.add("Customer Name:  ");
         preface2.add(customerPreFix +" "+ customerFirstName +" " + customerLastName);
         preface2.add("\n");
         preface2.add("Address:  ");
         preface2.add(customerAddressLine1 +" "+ customerAddressLine2);
         preface2.add("\n");
         preface2.add(customerCity +" "+ customerState +" "+customerZip +" "+customerCountry);
         preface2.add("\n");
         preface2.add("Account Number:  ");
         preface2.add(accountNumber);
         preface2.add(new Chunk(glue));
         preface2.add("Customer Id:  ");
         preface2.add(customerId);
         document.add(preface2);
         
         Paragraph preface3 = new Paragraph();
         preface3.add("Currency: ");
         preface3.add(currency);
         preface3.setFont(subFont);
         preface3.setAlignment(Element.ALIGN_RIGHT);
         addEmptyLine(preface3, 2);
         document.add(preface3);
         
         // Adding Table
         PdfPTable table = new PdfPTable(5);
         table.setWidthPercentage(100f);
         PdfPCell c1 = new PdfPCell(new Phrase("TransactionId"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("TransactionTimestamp"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("Description"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("Status"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("Amount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         table.setHeaderRows(1);
         	
		//System.out.println("----------------------Statement Details-------------------------");
		for (int i = 0; i < jArray.length(); i++) {
		    JSONObject jsonobject = jArray.getJSONObject(i);
		    String transactionId = jsonobject.getString("TransactionId");
		    String transactionTimestamp = jsonobject.getString("TransactionTimestamp");
		    String description = jsonobject.getString("Description");
		    String status = jsonobject.getString("Status");
		    String amount = jsonobject.getString("Amount");
		    table.addCell(transactionId);
		    table.addCell(transactionTimestamp);
		    table.addCell(description);
		    table.addCell(status);
		    table.addCell(amount);
		    
		}
		document.add(table);
		document.close();

		
		return null;
	}
	
	private static void addEmptyLine(Paragraph paragraph, int number) {
        for (int i = 0; i < number; i++) {
            paragraph.add(new Paragraph(" "));
        }
    }

}
