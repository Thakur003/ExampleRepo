package getstatementdetails;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;

import customexception.InvalidPatternException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

public class CustomValidationNew implements Validator {
	
	Pattern pattern = Pattern.compile("\\d+");
	String[] dateDatterns = {"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm"};

	@Override
	public ValidationResult validate(MuleEvent event) {
		
		try {
			String acc = event.getMessageAsString();
			JSONObject json = (JSONObject) JSONSerializer.toJSON(acc);
			String accountId = json.getString("accountId");
			String startDate = json.getString("startDate");
			String endDate = json.getString("endDate");
			
			
			boolean dateValidationCheck = Arrays.asList(dateDatterns).stream()
			        .anyMatch(pattern -> {
			            try {
			                LocalDateTime.parse(startDate, DateTimeFormatter.ofPattern(pattern));
			                LocalDateTime.parse(endDate, DateTimeFormatter.ofPattern(pattern));			                
			                return true;
			            } catch (Exception e) {
			                return false;
			            }
			        });
			
			
			//AccountNumber validation
			Matcher matcher = pattern.matcher(accountId);
			if(accountId.length() == 0) {				
				return ImmutableValidationResult.error("Please enter the AccountId.");
			}else if(!(matcher.matches()) || accountId.length() >= 100){
				throw new InvalidPatternException("Doesn't match the format of AccountId: "+accountId);
			}
			
			//Date validation
			if(!(dateValidationCheck)) {
				return ImmutableValidationResult.error("Date should be in yyyy-MM-dd HH:mm:ss or yyyy-MM-dd HH:mm format");
			}
			
		}
		catch(InvalidPatternException ex) {
			System.out.println("Doesn't match the format of AccountId");;
		}
		catch (MuleException e) {
			e.printStackTrace();
		}
		 
		return ImmutableValidationResult.ok();
	}
}
