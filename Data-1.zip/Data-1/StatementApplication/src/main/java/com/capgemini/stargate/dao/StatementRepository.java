package com.capgemini.stargate.dao;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.stargate.model.Transaction;



//@NoRepositoryBean
@Repository
public interface StatementRepository extends CrudRepository<Transaction, String>
{
	@Query (value = "SELECT * from Bank, Branch, Customer, accountdescriptor, account, transaction where Bank.BankId = Branch.BankId and Branch.BranchId = Customer.BranchId and " + 
			"Customer.CustomerId = accountdescriptor.CustomerId and " +
			"accountdescriptor.AccountDescriptorId = account.AccDescriptorId and account.AccountMasterId = transaction.AccountMasterId " +
			"and accountdescriptor.AccountId = :accountId and transactiontimestamp between :startDate and :endDate", nativeQuery = true)
public List<Transaction> getStatements(@Param("accountId") String accountId, @Param("startDate") String startDate, @Param("endDate") String endDate);
}