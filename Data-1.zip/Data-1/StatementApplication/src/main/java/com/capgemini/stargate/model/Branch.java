
package com.capgemini.stargate.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "branch")
public class Branch
    extends Bank
    implements Serializable
{

    final static long serialVersionUID = 7386706152877231366L;
    private String branchId;
    private String ifsc;
    private String address;
    private String city;
    private String state;
    private String country;
    private String zip;
    private String telephone;
    private String email;
    private String branchName;

    /**
     * Creates a new Branch.
     * 
     */
    public Branch() {
        super();
    }

    /**
     * Creates a new Branch.
     * 
     */
    public Branch(String bankId, String name, String branchId, String ifsc, String address, String city, String state, String country, String zip, String telephone, String email, String branchName) {
        super(bankId, name);
        this.branchId = branchId;
        this.ifsc = ifsc;
        this.address = address;
        this.city = city;
        this.state = state;
        this.country = country;
        this.zip = zip;
        this.telephone = telephone;
        this.email = email;
        this.branchName = branchName;
    }

    /**
     * Returns the branchId.
     * 
     * @return
     *     branchId
     */
    @JsonIgnore
    public String getBranchId() {
        return branchId;
    }

    /**
     * Set the branchId.
     * 
     * @param branchId
     *     the new branchId
     */
    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }

    /**
     * Returns the ifsc.
     * 
     * @return
     *     ifsc
     */
    @JsonIgnore
    public String getIfsc() {
        return ifsc;
    }

    /**
     * Set the ifsc.
     * 
     * @param ifsc
     *     the new ifsc
     */
    public void setIfsc(String ifsc) {
        this.ifsc = ifsc;
    }

    /**
     * Returns the address.
     * 
     * @return
     *     address
     */
    @JsonIgnore
    public String getAddress() {
        return address;
    }

    /**
     * Set the address.
     * 
     * @param address
     *     the new address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Returns the city.
     * 
     * @return
     *     city
     */
    @JsonIgnore
    public String getCity() {
        return city;
    }

    /**
     * Set the city.
     * 
     * @param city
     *     the new city
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Returns the state.
     * 
     * @return
     *     state
     */
    @JsonIgnore
    public String getState() {
        return state;
    }

    /**
     * Set the state.
     * 
     * @param state
     *     the new state
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Returns the country.
     * 
     * @return
     *     country
     */
    @JsonIgnore
    public String getCountry() {
        return country;
    }

    /**
     * Set the country.
     * 
     * @param country
     *     the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Returns the zip.
     * 
     * @return
     *     zip
     */
    @JsonIgnore
    public String getZip() {
        return zip;
    }

    /**
     * Set the zip.
     * 
     * @param zip
     *     the new zip
     */
    public void setZip(String zip) {
        this.zip = zip;
    }

    /**
     * Returns the telephone.
     * 
     * @return
     *     telephone
     */
    @JsonIgnore
    public String getTelephone() {
        return telephone;
    }

    /**
     * Set the telephone.
     * 
     * @param telephone
     *     the new telephone
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    /**
     * Returns the email.
     * 
     * @return
     *     email
     */
    @JsonIgnore
    public String getEmail() {
        return email;
    }

    /**
     * Set the email.
     * 
     * @param email
     *     the new email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the branchName.
     * 
     * @return
     *     branchName
     */
    @JsonIgnore
    public String getBranchName() {
        return branchName;
    }

    /**
     * Set the branchName.
     * 
     * @param branchName
     *     the new branchName
     */
    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(branchId).append(ifsc).append(address).append(city).append(state).append(country).append(zip).append(telephone).append(email).append(branchName).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Branch otherObject = ((Branch) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(branchId, otherObject.branchId).append(ifsc, otherObject.ifsc).append(address, otherObject.address).append(city, otherObject.city).append(state, otherObject.state).append(country, otherObject.country).append(zip, otherObject.zip).append(telephone, otherObject.telephone).append(email, otherObject.email).append(branchName, otherObject.branchName).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("branchId", branchId).append("ifsc", ifsc).append("address", address).append("city", city).append("state", state).append("country", country).append("zip", zip).append("telephone", telephone).append("email", email).append("branchName", branchName).toString();
    }

}
