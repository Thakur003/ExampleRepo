
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "account")
public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = 7365223858175435814L;
    private String accountMasterId;
    private String parentAccountId;
    private String nickName;
    private String lineOfBusiness;
    private String accountNumber;
    private Long interestRate;
    private String currency;
    private Long transferIn;
    private Long transferOut;
    @Enumerated(EnumType.STRING)
    private InterestRateType interestRateType;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(String bankId, String name, String branchId, String ifsc, String address, String city, String state, String country, String zip, String telephone, String email, String branchName, String customerId, Date dateOfBirth, String taxId, String governmentId, String emailId, String password, String accountId, String displayName, String description, AccountStatus status, String accountDescriptorid, String accountMasterId, String parentAccountId, String nickName, String lineOfBusiness, String accountNumber, Long interestRate, String currency, Long transferIn, Long transferOut, InterestRateType interestRateType) {
        super(bankId, name, branchId, ifsc, address, city, state, country, zip, telephone, email, branchName, customerId, dateOfBirth, taxId, governmentId, emailId, password, accountId, displayName, description, status, accountDescriptorid);
        this.accountMasterId = accountMasterId;
        this.parentAccountId = parentAccountId;
        this.nickName = nickName;
        this.lineOfBusiness = lineOfBusiness;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.currency = currency;
        this.transferIn = transferIn;
        this.transferOut = transferOut;
        this.interestRateType = interestRateType;
    }

    /**
     * Returns the accountMasterId.
     * 
     * @return
     *     accountMasterId
     */
    @JsonIgnore
    public String getAccountMasterId() {
        return accountMasterId;
    }

    /**
     * Set the accountMasterId.
     * 
     * @param accountMasterId
     *     the new accountMasterId
     */
    public void setAccountMasterId(String accountMasterId) {
        this.accountMasterId = accountMasterId;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    @JsonIgnore
    public String getParentAccountId() {
        return parentAccountId;
    }

    /**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     */
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }

    /**
     * Returns the nickName.
     * 
     * @return
     *     nickName
     */
    @JsonIgnore
    public String getNickName() {
        return nickName;
    }

    /**
     * Set the nickName.
     * 
     * @param nickName
     *     the new nickName
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * Returns the lineOfBusiness.
     * 
     * @return
     *     lineOfBusiness
     */
    @JsonIgnore
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Set the lineOfBusiness.
     * 
     * @param lineOfBusiness
     *     the new lineOfBusiness
     */
    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    @JsonIgnore
    public Long getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Long interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Returns the transferIn.
     * 
     * @return
     *     transferIn
     */
    @JsonIgnore
    public Long getTransferIn() {
        return transferIn;
    }

    /**
     * Set the transferIn.
     * 
     * @param transferIn
     *     the new transferIn
     */
    public void setTransferIn(Long transferIn) {
        this.transferIn = transferIn;
    }

    /**
     * Returns the transferOut.
     * 
     * @return
     *     transferOut
     */
    @JsonIgnore
    public Long getTransferOut() {
        return transferOut;
    }

    /**
     * Set the transferOut.
     * 
     * @param transferOut
     *     the new transferOut
     */
    public void setTransferOut(Long transferOut) {
        this.transferOut = transferOut;
    }

    /**
     * Returns the interestRateType.
     * 
     * @return
     *     interestRateType
     */
    @JsonIgnore
    public InterestRateType getInterestRateType() {
        return interestRateType;
    }

    /**
     * Set the interestRateType.
     * 
     * @param interestRateType
     *     the new interestRateType
     */
    public void setInterestRateType(InterestRateType interestRateType) {
        this.interestRateType = interestRateType;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(accountMasterId).append(parentAccountId).append(nickName).append(lineOfBusiness).append(accountNumber).append(interestRate).append(currency).append(transferIn).append(transferOut).append(interestRateType).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(accountMasterId, otherObject.accountMasterId).append(parentAccountId, otherObject.parentAccountId).append(nickName, otherObject.nickName).append(lineOfBusiness, otherObject.lineOfBusiness).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(currency, otherObject.currency).append(transferIn, otherObject.transferIn).append(transferOut, otherObject.transferOut).append(interestRateType, otherObject.interestRateType).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("accountMasterId", accountMasterId).append("parentAccountId", parentAccountId).append("nickName", nickName).append("lineOfBusiness", lineOfBusiness).append("accountNumber", accountNumber).append("interestRate", interestRate).append("currency", currency).append("transferIn", transferIn).append("transferOut", transferOut).append("interestRateType", interestRateType).toString();
    }

}
