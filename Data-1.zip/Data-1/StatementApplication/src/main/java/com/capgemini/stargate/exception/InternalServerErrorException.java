package com.capgemini.stargate.exception;

public class InternalServerErrorException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public InternalServerErrorException(String ex) 
	 {
		super(ex);
	 }
}
