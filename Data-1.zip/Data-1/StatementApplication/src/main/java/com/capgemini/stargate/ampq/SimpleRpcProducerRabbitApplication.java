package com.capgemini.stargate.ampq;


import java.util.List;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import com.capgemini.stargate.model.Transaction;
import org.springframework.amqp.core.Queue;


@EnableScheduling
@SpringBootApplication
public class SimpleRpcProducerRabbitApplication {

	
	  private final RabbitTemplate template;

	   
	    @Autowired
	    public SimpleRpcProducerRabbitApplication(RabbitTemplate template) {
	        this.template = template;
	    }

	    //@Scheduled(fixedRate = 1000)
	    public void sendMessage(List<Transaction> transactionDetails) {	        
	        this.template.convertAndSend("Thakur", transactionDetails.toString());
	    }

	    @Bean
	    public Queue queue() {
	        return new Queue("Thakur", false);
	    }
}
