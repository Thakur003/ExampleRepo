package com.capgemini.stargate.controller;

import com.capgemini.stargate.ampq.SimpleRpcProducerRabbitApplication;
import com.capgemini.stargate.exception.InternalServerErrorException;
import com.capgemini.stargate.exception.InvalidAccountIdException;
import com.capgemini.stargate.model.Transaction;
import com.capgemini.stargate.service.BankCatalogClient;
import com.capgemini.stargate.service.PDFUtility;
import com.capgemini.stargate.service.StatementService;
import com.itextpdf.text.DocumentException;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

@RestController
@RequestMapping(value = "/api/v1/accounts", produces = "application/json")
public class StatementDetailController
{
	@Autowired
	StatementService statementService;
	
	@Autowired
	BankCatalogClient bankCatalogClient;
	
	@Autowired
	SimpleRpcProducerRabbitApplication simpleRpcProducerRabbitApplication;
	
	@Autowired
	PDFUtility pDFUtility;
	
	
	 
	 @RequestMapping(value ="/statements" ,method = RequestMethod.POST, consumes = "application/json")
	 public ResponseEntity<?> getAccountStatements(@RequestHeader(name = "Content-Type")
     String contentType, @RequestBody String accountId, String startDate, String endDate) throws IOException, DocumentException
	    {
		 	HttpHeaders headers = new HttpHeaders();
			 try{
		 		JSONObject json = (JSONObject) JSONSerializer.toJSON(accountId);
		 		String accId = json.getString("accountId");
		 		String stDate = json.getString("startDate");
		 		String enDate = json.getString("endDate");
		    	List<Transaction> accountDetails = statementService.getStatementCustom(accId, stDate, enDate);
		    	
		    	//Consuming the SOAP service
		    	bankCatalogClient.getBankById(accountDetails.get(0).getCustomerId());
		    	
		    	// Calling AMQP
		    	simpleRpcProducerRabbitApplication.sendMessage(statementService.getStatementCustom(accId, stDate, enDate));
		    	
		    	// Generating PDF file
		    	ByteArrayInputStream bis = pDFUtility.getStatementsInPDF(accountDetails);
		    	headers.set("Content-Disposition", "inline; filename = statement.pdf");
		    	//return ResponseEntity.ok().body(accountDetails);
		    	return ResponseEntity .ok() .headers(headers) .contentType(MediaType.APPLICATION_PDF).body(new InputStreamResource(bis));
			 }
	 		catch(InvalidAccountIdException ex){
	 			return new CustomExceptionHandlerController().handleInvalidAccountId(ex);
	 		 }
	 		catch(NoSuchElementException ex){
	 			return new CustomExceptionHandlerController().handleAccountIdNotFound(ex);
	 		 }
	 		catch(InternalServerErrorException ex){
	 			return new CustomExceptionHandlerController().handleInternalServerError(ex);
	 		 }
	    }
	}