package com.capgemini.stargate.controller;

import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.capgemini.stargate.exception.AccountIdNotFoundException;
import com.capgemini.stargate.exception.ErrorDetails;
import com.capgemini.stargate.exception.InvalidAccountIdException;
import com.capgemini.stargate.exception.InvalidDateFormatException;

@ControllerAdvice
public class CustomExceptionHandlerController extends ResponseEntityExceptionHandler
{
	
	@ExceptionHandler(value=AccountIdNotFoundException.class)
	public final ResponseEntity<ErrorDetails> handleAccountIdNotFound(NoSuchElementException ex) {
		 ErrorDetails errorDetails = new ErrorDetails("404","ACCOUNT NOT FOUND!");
	    return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	} 
	
	@ExceptionHandler(value=InvalidAccountIdException.class)
	public final ResponseEntity<ErrorDetails> handleInvalidAccountId(InvalidAccountIdException ex) {
		 ErrorDetails errorDetails = new ErrorDetails("400","INVALID/NULL ACCOUNT ID!");
	    return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value=InvalidDateFormatException.class)
	public final ResponseEntity<ErrorDetails> handleInvalidAccountId(InvalidDateFormatException ex) {
		 ErrorDetails errorDetails = new ErrorDetails("400","DATE SHOULD BE IN YYYY-MM-DD HH:MM:SS FORMAT!");
	    return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleInternalServerError(Exception ex) {
		 ErrorDetails errorDetails = new ErrorDetails("500","SOMETHING WENT WRONG!INTERNAL SERVER ERROR!");
	    return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
