package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.core.instrument.MeterRegistry;

@RestController
public class GreetingController {	  
		private final MeterRegistry metericRegistry;
	    @Autowired
	    public GreetingController(MeterRegistry metericRegistry){
	        this.metericRegistry = metericRegistry;
	    }

	    @GetMapping("/")
	    public String hello() {
	    	metericRegistry.counter("counter.services.greeting.invoked");
	        return "Hello World!!!";
	    } 
	 

}
