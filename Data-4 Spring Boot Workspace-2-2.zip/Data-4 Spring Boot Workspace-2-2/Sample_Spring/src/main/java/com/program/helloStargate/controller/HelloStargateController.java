package com.program.helloStargate.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloStargateController {

	

	@RequestMapping(value = "/hello")
	public ModelAndView showMessage() {
		System.out.println("in controller");

		String message = "Welcome to Spring MVC!";
		//model.addAttribute("message", "Hello Spring MVC Framework!");
		
		//model.addAttribute(message);
	      //return "hello";
		
		return new ModelAndView("hellopage", "message", message);  
		
	}
	


	
	/*@RequestMapping(value = "/hello")
	public String showMessage(Model model) {
		System.out.println("in controller");

		String message = "Welcome to Spring MVC!";
		model.addAttribute("message", "Hello Spring MVC Framework!");
		model.addAttribute(message);
	     return "hello";
	
		
	}*/

}
