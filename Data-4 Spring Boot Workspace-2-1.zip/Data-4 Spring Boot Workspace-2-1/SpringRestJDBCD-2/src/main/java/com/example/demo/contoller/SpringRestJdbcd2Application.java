package com.example.demo.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepository;


@SpringBootApplication(scanBasePackages={
		"com.example.demo.repo"})
@RestController
public class SpringRestJdbcd2Application {
	  @Autowired
	EmployeeRepository empRepo;
	public static void main(String[] args) {
		SpringApplication.run(SpringRestJdbcd2Application.class, args);
	}
    @RequestMapping("/getAllEmp")
    @ResponseBody
    public List<Employee> getAllEmployee(){
        return empRepo.getAllEmployee();
    }
}
