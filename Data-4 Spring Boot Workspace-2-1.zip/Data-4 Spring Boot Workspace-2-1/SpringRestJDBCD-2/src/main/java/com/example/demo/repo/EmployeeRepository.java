package com.example.demo.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;



@Repository
public class EmployeeRepository {
	 
	 JdbcTemplate template;
	 
	
	 @Autowired
	 public EmployeeRepository(JdbcTemplate template) {
		super();
		this.template = template;
	}



	public List<Employee> getAllEmployee() {
		List<Employee> emp = template.query("select empId, empFirstName,empLastName from emp",(result,rowNum)->new Employee(result.getInt("empId"),
                result.getString("empFirstName"),result.getString("empLastName")));
		return emp;
	    }
}
