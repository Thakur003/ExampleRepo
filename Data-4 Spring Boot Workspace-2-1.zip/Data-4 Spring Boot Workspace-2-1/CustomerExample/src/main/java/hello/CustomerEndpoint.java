package hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import io.spring.guides.customerdemo.Customer;
import io.spring.guides.customerdemo.GetAllCustomerRequest;
import io.spring.guides.customerdemo.GetAllCustomerResponse;
import io.spring.guides.customerdemo.GetCustomerByIDRequest;
import io.spring.guides.customerdemo.GetCustomerByIDResponse;


@Endpoint
public class CustomerEndpoint {
	private static final String NAMESPACE_URI = "http://spring.io/guides/CustomerDemo";

	private CustomerRepository customerRepository;
	
	@Autowired
	public CustomerEndpoint(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}
	
	/*
	 * Returns GetCustomerByIDResponse object for particular customer id 
	 */
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCustomerByIDRequest")
	@ResponsePayload
	public GetCustomerByIDResponse getCustomerByID(@RequestPayload GetCustomerByIDRequest request) {
		GetCustomerByIDResponse response = new GetCustomerByIDResponse();
		response.setCustomer(customerRepository.getCustomerByID(request.getId()));
		return response;
	}
	
	/*
	 * Returns all customers list
	 */
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getAllCustomerRequest")
	@ResponsePayload
	public GetAllCustomerResponse getAllCustomers(@RequestPayload GetAllCustomerRequest request) {
		GetAllCustomerResponse response = new GetAllCustomerResponse();		
		List<Customer> cust = customerRepository.allCustList();
		response.getCustomer().addAll(cust);
		return response;
				
	}
}
