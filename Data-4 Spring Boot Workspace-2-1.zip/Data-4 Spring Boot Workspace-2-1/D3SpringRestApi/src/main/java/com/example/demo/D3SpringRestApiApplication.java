package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication (scanBasePackages={"com.example.demo"})
public class D3SpringRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(D3SpringRestApiApplication.class, args);
	}
}
