package com.example.demo.service;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Employee;

public interface UserRepo extends CrudRepository<Employee, Integer> {

}
