package com.example.demo.controller;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.demo.model.Employee;
import com.example.demo.model.User;
import com.example.demo.service.UserRepo;
import com.example.demo.service.UserService;





@RestController
@RequestMapping("/api/v1")
public class RestApiController {

	@Autowired
	UserService userService;
	
	@Autowired
	UserRepo user;
	
	@GetMapping("/emp")
    public List<Employee> getAllNotes() {
        return (List<Employee>) user.findAll();
    }

	// -------------------Retrieve All Users---------------------------------------------
/*
	@RequestMapping(value = "/user/", method = RequestMethod.GET)
	public ResponseEntity<List<User>> listAllUsers() {
		List<User> users = userService.findAllUsers();		
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	
	
	// -------------------Create a User-------------------------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.POST)
	public ResponseEntity<String> createUser(@RequestBody User user, UriComponentsBuilder ucBuilder) {
		String message = "Success";
		userService.saveUser(user);		
		 return new ResponseEntity<String>(message,HttpStatus.CREATED);
    }
	
	// ------------------- Delete a User By Id-----------------------------------------

		@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
		public ResponseEntity<String> deleteUser(@PathVariable("id") long id) {
			String message = "Success";
			userService.deleteUserById(id);
			return new ResponseEntity<String>(message, HttpStatus.OK);
		}*/

}