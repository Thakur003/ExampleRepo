package com.example.demo;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class ConsumerTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumerTestApplication.class, args);
	}
	
	@RabbitListener(queues = "spring-boot-test") //@RabbitListener to create a listener endpoint
	public void process(String message) {
		System.out.println("Welcome to " + message);
	}

	@Bean
	public Queue queue(){					//The queue() method returns an queue with durability set to false
		return new Queue("spring-boot-test", false);
	}
}
