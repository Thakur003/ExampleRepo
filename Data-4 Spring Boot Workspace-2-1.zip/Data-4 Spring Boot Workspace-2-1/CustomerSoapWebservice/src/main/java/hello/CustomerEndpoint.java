package hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import io.spring.guides.custsoapws.GetCustomerRequestById;
import io.spring.guides.custsoapws.GetCustomerResponseById;



@Endpoint
public class CustomerEndpoint {
	//private static final String NAMESPACE_URI = "http://spring.io/guides/custsoapws";
	private static final String NAMESPACE_URI = "http://spring.io/guides/custsoapws";
	private CustomerRepository customerRepository;
	
	
	@Autowired
	public CustomerEndpoint(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCustomerRequestById")
	@ResponsePayload
	public GetCustomerResponseById getCustomer(@RequestPayload GetCustomerRequestById request) {
		System.out.println("Inside Customer Endpoint.....!!!!!!!!!");
		GetCustomerResponseById response = new GetCustomerResponseById();
		response.setCustomer(customerRepository.findCustomer(request.getId()));

		return response;
	}
}
