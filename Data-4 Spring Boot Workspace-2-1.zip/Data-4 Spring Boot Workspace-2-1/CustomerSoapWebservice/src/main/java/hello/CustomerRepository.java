package hello;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import io.spring.guides.custsoapws.Customer;

@Component
public class CustomerRepository {
	private static final Map<Integer, Customer> customers = new HashMap<>();

	@PostConstruct
	public void initData() {		
		
		Customer cust = new Customer();
		cust.setId(1111);
		cust.setName("Vijendra");
		cust.setAddress("Pune");
		cust.setContact(8773521);
		customers.put(cust.getId(), cust);
		System.out.println("Inside Customer Repository.....!!!!!!!!!");
	}

	public Customer findCustomer(int id) {
		Assert.notNull(id, "The id name must not be null");
		return customers.get(id);
	}
}
