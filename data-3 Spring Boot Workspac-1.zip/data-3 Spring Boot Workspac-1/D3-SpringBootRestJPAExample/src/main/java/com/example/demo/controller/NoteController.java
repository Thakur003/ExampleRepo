package com.example.demo.controller;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Note;
import com.example.demo.repository.NoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * Created by rajeevkumarsingh on 27/06/17.
 */
@RestController
@RequestMapping("/api")
public class NoteController {

    @Autowired
    NoteRepository noteRepository;

    /*@GetMapping("/notes")
    public List<Note> getAllNotes() {
        return (List<Note>) noteRepository.findAll();
    }*/
    
    @GetMapping("/notes")
    public ResponseEntity <List<Note>> getAllNotes() {
        List<Note> notes = (List<Note>) noteRepository.findAll();
        return new ResponseEntity<List<Note>>(notes, HttpStatus.OK);
    }

    @PostMapping("/notes")
    public ResponseEntity<Note> createNote(@Valid @RequestBody Note note) {
    	note = noteRepository.save(note);	
		return new ResponseEntity<Note>(note, HttpStatus.CREATED);
    }
    
    @GetMapping("/notes/{id}")
    public ResponseEntity<Optional<Note>> getNoteById(@PathVariable(value = "id") Long id) {
        Optional<Note> note = noteRepository.findById(id);
        return ResponseEntity.ok().body(note);
        
    }
   

    @PutMapping(value = "/notes/{id}")
	public ResponseEntity<Note> updateNote(@PathVariable(value = "id") long id, @RequestBody Note noteDetails) {
    	 Note note = noteRepository.findById(id)
                 .orElseThrow(() -> new ResourceNotFoundException("Note", "id", id));
    	 note.setTitle(noteDetails.getTitle());
    	 note.setContent(noteDetails.getContent());
		Note updatedNote = noteRepository.save(note);
		return new ResponseEntity<Note>(updatedNote, HttpStatus.UPGRADE_REQUIRED);
	}

    @DeleteMapping("/notes/{id}")
    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long id) {
        Note note = noteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Note", "id", id));

        noteRepository.delete(note);

        return ResponseEntity.ok().build();
    }
}
