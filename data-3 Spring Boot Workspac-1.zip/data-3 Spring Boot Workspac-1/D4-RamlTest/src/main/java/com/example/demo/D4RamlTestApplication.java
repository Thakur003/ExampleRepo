package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D4RamlTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(D4RamlTestApplication.class, args);
		System.out.println("Inside Spring controller......!!!!!!!!");
	}
}
