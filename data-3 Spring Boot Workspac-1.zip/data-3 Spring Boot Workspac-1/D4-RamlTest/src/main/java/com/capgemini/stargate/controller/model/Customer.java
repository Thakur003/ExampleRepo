
package com.capgemini.stargate.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Customer implements Serializable
{

    final static long serialVersionUID = 3205556639615547832L;
    private Long customerId;
    private String customerName;
    private String address;

    /**
     * Creates a new Customer.
     * 
     */
    public Customer() {
        super();
    }

    /**
     * Creates a new Customer.
     * 
     */
    public Customer(Long customerId, String customerName, String address) {
        super();
        this.customerId = customerId;
        this.customerName = customerName;
        this.address = address;
    }

    /**
     * Returns the customerId.
     * 
     * @return
     *     customerId
     */
    public Long getCustomerId() {
        return customerId;
    }

    /**
     * Set the customerId.
     * 
     * @param customerId
     *     the new customerId
     */
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the customerName.
     * 
     * @return
     *     customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Set the customerName.
     * 
     * @param customerName
     *     the new customerName
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * Returns the address.
     * 
     * @return
     *     address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Set the address.
     * 
     * @param address
     *     the new address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(customerId).append(customerName).append(address).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Customer otherObject = ((Customer) other);
        return new EqualsBuilder().append(customerId, otherObject.customerId).append(customerName, otherObject.customerName).append(address, otherObject.address).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("customerId", customerId).append("customerName", customerName).append("address", address).toString();
    }

}
